// Backend API BASE URL
export const API_BASE_URL = "https://c077816c97e1.ngrok.app";
// Contract address
export const CONTRACT_ADDRESS = "";
