// Backend API BASE URL
export const API_BASE_URL = "https://c077816c97e1.ngrok.app";
// Contract address(base sepolia)
export const CONTRACT_BASE_SEPOLIA_ADDRESS = "0x0a730733Ee85466278Cd31F452165A30971Ecdbd";
// Contract address(base)
export const CONTRACT_BASE_ADDRESS = "0xa05Db9C31B6ffB6aB817D346E99095e1c1c8317D";
