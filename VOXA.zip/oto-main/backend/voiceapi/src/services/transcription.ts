// Re-export everything from the new abstracted transcription service
export * from './transcription/index';
export { transcriptionService } from './transcription/index';
