from agno.models.openai import OpenAIChat

openai_model = OpenAIChat(id="gpt-4o")
