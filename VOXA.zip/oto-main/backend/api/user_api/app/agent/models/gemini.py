from agno.models.google import Gemini

gemini_model = Gemini(id="gemini-2.0-flash")
