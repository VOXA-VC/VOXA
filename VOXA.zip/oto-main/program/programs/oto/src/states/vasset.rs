/*
use anchor_lang::prelude::*;

#[account]
#[derive(InitSpace)]
pub struct VAsset {
    pub nft_mint: Pubkey,

    pub record_start_time: u64,
    pub record_end_time: u64,

    pub quality: u32,
    pub duration: u32,
    pub active_duration: u32,
    pub location_rarity: u32,
    pub topic_rarity: u32,

    pub blacklisted: bool,

    pub bump: u8,
}
*/
